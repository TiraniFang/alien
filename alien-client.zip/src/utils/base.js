import api from '../api/request'

// export default getIntergral(){
//   console.log(22333)
// } 